// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-app.js";
import { getFirestore, collection } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-firestore.js";
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAWYNTnCUUN0svjorjpqM7oiyT6WZ9ti28",
  authDomain: "groupweb-8a441.firebaseapp.com",
  projectId: "groupweb-8a441",
  storageBucket: "groupweb-8a441.firebasestorage.app",
  messagingSenderId: "158182736500",
  appId: "1:158182736500:web:a52d12b44f7b464d6c4721",
  measurementId: "G-8M84HFBS72"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const groupsCol = collection(db, "groups");

export { db, groupsCol };