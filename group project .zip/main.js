// ================== IMPORT FIREBASE ==================
import { db, groupsCol } from "./firebase-config.js";
import { addDoc, getDocs, updateDoc, deleteDoc, doc, query, where } from "https://www.gstatic.com/firebasejs/10.6.0/firebase-firestore.js";

// ================== USER DATA ==================
let userData = JSON.parse(localStorage.getItem("userData")) || {
  name: "",
  email: "",
  coins: 8,
  submittedGroups: 0,
  joinedGroups: {}
};
function saveUserData() { localStorage.setItem("userData", JSON.stringify(userData)); }

// ================== CONSTANTS ==================
const JOIN_COST = 4;
const SUBMIT_COST = 10;

// ================== COINS DISPLAY ==================
function updateCoinsDisplay() {
  document.querySelectorAll("#userCoins, #cardCoins").forEach(el => { if(el) el.textContent = userData.coins; });
}

// ================== USER INFO ==================
function updateSubmitInfo() {
  const nameEl = document.getElementById("submitUserName");
  const countEl = document.getElementById("userGroupsCount");
  if(nameEl) nameEl.textContent = userData.name || "User";
  if(countEl) countEl.textContent = userData.submittedGroups;
}

// ================== FETCH METADATA ==================
async function fetchGroupMetadata(link) {
  try {
    const res = await fetch(`http://localhost:3000/api/getMetadata?url=${encodeURIComponent(link)}`);
    const data = await res.json();
    return { name: data.title || "", dp: data.image || "" };
  } catch {
    return { name: "", dp: "" };
  }
}

// ================== FETCH GROUPS ==================
async function fetchGroups(platform = "whatsapp") {
  const q = query(groupsCol, where("platform", "==", platform));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() }));
}

// ================== RENDER GROUPS ==================
async function renderGroups(platform = "whatsapp") {
  const container = document.getElementById("groupsContainer");
  if(!container) return;

  const groups = await fetchGroups(platform);
  container.innerHTML = "";
  if(groups.length === 0) {
    container.innerHTML = '<p style="text-align:center;opacity:.6">No groups found</p>';
    return;
  }

  groups.forEach(g => {
    const card = document.createElement("div");
    card.className = "wa-group-card";
    card.innerHTML = `
      <img class="group-dp" src="${g.dp}">
      <div class="group-info">
        <h4>${g.name}</h4>
        <p>Members: <span id="members-${g.id}">${g.members}</span></p>
        <small>Views: <span id="views-${g.id}">${g.views}</span></small>
      </div>
      <a href="#" class="join-btn" data-id="${g.id}">Join</a>
    `;
    container.appendChild(card);
  });

  attachJoinLogic(platform);
}

// ================== JOIN LOGIC ==================
async function attachJoinLogic(platform) {
  const groups = await fetchGroups(platform);
  document.querySelectorAll(".join-btn").forEach(btn => {
    btn.onclick = async e => {
      e.preventDefault();
      const groupId = btn.dataset.id;
      const group = groups.find(g => g.id === groupId);
      if(!group) return;

      if(userData.joinedGroups[groupId]) { window.open(group.link, "_blank"); return; }
      if(group.members >= 50 && userData.coins < JOIN_COST) return alert("Not enough coins!");
      if(group.members >= 50) userData.coins -= JOIN_COST;

      userData.joinedGroups[groupId] = true;
      saveUserData();
      updateCoinsDisplay();

      const docRef = doc(groupsCol, groupId);
      await updateDoc(docRef, { members: group.members + 1, views: group.views + 1 });

      document.getElementById(`views-${group.id}`).textContent = group.views + 1;
      document.getElementById(`members-${group.id}`).textContent = group.members + 1;

      window.open(group.link, "_blank");
    };
  });
}

// ================== SUBMIT GROUP ==================
document.getElementById("groupForm")?.addEventListener("submit", async e => {
  e.preventDefault();

  const platform = document.getElementById("category").value.trim().toLowerCase();
  const groupType = document.getElementById("groupType").value.trim() || "General";
  const link = document.getElementById("groupLink").value.trim();
  const customName = document.getElementById("groupName")?.value.trim();
  const imageInput = document.getElementById("groupDP");

  if(!platform || !link) return alert("Fill all required fields");
  if(userData.coins < SUBMIT_COST) return alert("Not enough coins");

  try {
    const groupName = customName || `${capitalize(platform)} ${groupType} Group`;

    let dp = getDefaultDP(platform);
    if(imageInput && imageInput.files.length > 0) {
      dp = await fileToBase64(imageInput.files[0]);
    } else {
      const meta = await fetchGroupMetadata(link);
      if(meta.dp) dp = meta.dp;
    }

    const initialMembers = Math.floor(Math.random() * 70) + 45;

    await addDoc(groupsCol, {
      name: groupName,
      dp,
      link,
      platform,
      members: initialMembers,
      views: 0,
      createdAt: Date.now(),
      createdBy: userData.email || userData.name
    });

    userData.coins -= SUBMIT_COST;
    userData.submittedGroups++;
    saveUserData();
    updateCoinsDisplay();
    updateSubmitInfo();

    alert("Group added successfully!");
    e.target.reset();
    renderGroups(platform);
    renderUserGroups();

  } catch (err) {
    console.error(err);
    alert("Group could not be added");
  }
});

// ================== RENDER USER GROUPS ==================
async function renderUserGroups() {
  const container = document.getElementById("myGroupsContainer");
  if(!container) return;

  const q = query(groupsCol, where("createdBy", "==", userData.email || userData.name));
  const snapshot = await getDocs(q);

  container.innerHTML = "";
  if(snapshot.empty) {
    container.innerHTML = '<p style="opacity:.6;text-align:center">No groups submitted yet</p>';
    return;
  }

  snapshot.forEach(docSnap => {
    const g = { id: docSnap.id, ...docSnap.data() };
    const card = document.createElement("div");
    card.className = "wa-group-card";
    card.innerHTML = `
      <img class="group-dp" src="${g.dp}">
      <div class="group-info">
        <h4>${g.name}</h4>
        <p>Members: ${g.members}</p>
        <small>Views: ${g.views}</small>
      </div>
      <div class="group-actions">
        <a href="${g.link}" target="_blank">Open Group</a>
        <button class="delete-btn">Delete</button>
      </div>
    `;
    container.appendChild(card);

    card.querySelector(".delete-btn").onclick = async () => {
      await deleteDoc(doc(groupsCol, g.id));
      userData.submittedGroups = Math.max(userData.submittedGroups - 1, 0);
      saveUserData();
      updateSubmitInfo();
      renderUserGroups();
      alert("Group deleted successfully!");
    };
  });
}

// ================== HELPERS ==================
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function getDefaultDP(platform) {
  if(platform === "whatsapp") return "img/whatsapp-icon.png";
  if(platform === "telegram") return "img/telegram-icon.png";
  if(platform === "facebook") return "img/facebook-icon.png";
  return "img/default-group.png";
}

function capitalize(str) { return str.charAt(0).toUpperCase() + str.slice(1); }

// ================== SOCIAL TABS ==================
document.querySelectorAll(".tab-link").forEach(tab => {
  tab.onclick = async e => {
    e.preventDefault();
    document.querySelectorAll(".tab-link").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    renderGroups(tab.dataset.platform);
  };
});

// ================== WATCH REWARDED AD ==================
async function watchAdReward() {
  const AD_PROVIDER_ID = "YOUR_AD_ID_HERE"; // Replace with real ID
  alert("Ad loading... Watch full ad to earn coins");

  // Demo ad watch timer
  await new Promise(resolve => setTimeout(resolve, 5000)); // 5 sec demo

  const COINS_EARNED = 10;
  userData.coins += COINS_EARNED;
  saveUserData();
  updateCoinsDisplay();
  alert(`🎉 You earned ${COINS_EARNED} coins!`);
}

// ================== ADD COINS BUTTONS ==================
document.getElementById("addCoins")?.addEventListener("click", watchAdReward);
document.querySelectorAll(".add-coin-btn").forEach(btn => btn.addEventListener("click", watchAdReward));

// ================== DARK MODE ==================
document.getElementById("darkSwitch")?.addEventListener("change", e => {
  document.body.classList.toggle("dark-mode", e.target.checked);
});

// ================== SIDEBAR ==================
const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("overlay");
document.getElementById("sidebarToggle")?.addEventListener("click", () => {
  sidebar.classList.add("open");
  overlay.classList.add("active");
});
document.querySelector(".close-btn")?.addEventListener("click", () => {
  sidebar.classList.remove("open");
  overlay.classList.remove("active");
});
overlay?.addEventListener("click", () => {
  sidebar.classList.remove("open");
  overlay.classList.remove("active");
});

// ================== INIT ==================
updateCoinsDisplay();
updateSubmitInfo();
renderGroups("whatsapp");
renderUserGroups();